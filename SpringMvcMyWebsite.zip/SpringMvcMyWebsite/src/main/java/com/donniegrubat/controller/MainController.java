package com.donniegrubat.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class MainController {
	
	@RequestMapping(value="/",method=RequestMethod.GET)
	public String Index(ModelMap map) 
	{
    	map.addAttribute("title","Welcome to  DG - Home");
		return "home";
	}
	
    @RequestMapping(value="home",method=RequestMethod.GET)
	public String Home(ModelMap map) 
	{
    	map.addAttribute("title","Welcome to  DG - Home");
		return "home";
	}
    
    @RequestMapping(value="about",method=RequestMethod.GET)
   	public String About(ModelMap map) 
   	{
       	map.addAttribute("title","Welcome to  DG - About");
   		return "about";
   	}
    
    @RequestMapping(value="post",method=RequestMethod.GET)
   	public String Post(ModelMap map) 
   	{
       	map.addAttribute("title","Welcome to  DG - Recent Post");
   		return "post";
   	}
    
    @RequestMapping(value="projects",method=RequestMethod.GET)
   	public String Projects(ModelMap map) 
   	{
       	map.addAttribute("title","Welcome to  DG - Projects");
   		return "projects";
   	}
    
    @RequestMapping(value="contact",method=RequestMethod.GET)
   	public String Contact(ModelMap map) 
   	{
       	map.addAttribute("title","Welcome to  DG - Contact");
   		return "contact";
   	}
}
